test = {   'name': 'q1a',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> manhattan_taxi.shape\n'
                                               '(82800, 10)',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> '
                                               "list(manhattan_taxi.groupby('date').size())[:8]\n"
                                               '[2337, 2411, 2177, 2368, 2630, '
                                               '2721, 2908, 3010]',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
