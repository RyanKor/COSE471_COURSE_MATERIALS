test = {   'name': 'q3d',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> 240 <= period_rmse <= 255\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.isclose(period_rmse, '
                                               '246.628688, 1e-4)\n'
                                               'True',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
