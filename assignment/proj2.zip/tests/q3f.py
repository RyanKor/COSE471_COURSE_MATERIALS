test = {   'name': 'q3f',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> 240 <= speed_rmse <= 255\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.isclose(speed_rmse, '
                                               '243.01798, 1e-4)\n'
                                               'True',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
