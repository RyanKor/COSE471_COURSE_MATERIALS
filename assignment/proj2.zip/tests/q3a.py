test = {   'name': 'q3a',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> 350 <= constant_rmse <= '
                                               '450\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.isclose(constant_rmse, '
                                               '399.14376, 1e-4)\n'
                                               'True',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
