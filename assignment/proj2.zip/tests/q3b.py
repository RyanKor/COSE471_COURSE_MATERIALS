test = {   'name': 'q3b',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> 260 <= simple_rmse <= 300\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.isclose(simple_rmse, '
                                               '276.78411, 1e-4)\n'
                                               'True',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
