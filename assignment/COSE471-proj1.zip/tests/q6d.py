test = {   'name': 'q6d',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> '
                                               'logistic_predictor_precision '
                                               '>= 0\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> logistic_predictor_recall '
                                               '>= 0\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> logistic_predictor_far >= '
                                               '0\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
